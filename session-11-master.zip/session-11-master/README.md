# Session 11

L'objectif de ces deux derniers cours et de travailler de manière autonome sur un
mini projet web en utilisant les techniques vues en cours.

Voici quelques projets donc vous pouvez vous inspirer:

**Chronologie/Timeline**

https://www.letemps.ch/monde/2017/11/15/harcelement-sexuel-laffaire-weinstein-suites-16-dates


**Quiz**

https://labs.letemps.ch/interactive/2017/quiz-unspunnen/


**Portraits**

https://www.letemps.ch/grand-format/une-semaine-smartphone


**Compteur**

https://www.washingtonpost.com/graphics/national/police-shootings-2016/


**Calculateur**

http://www.bbc.com/news/health-42013239

http://www.bbc.com/news/world-34808717

**Série de graphiques narratifs**

https://www.bloomberg.com/graphics/2015-dangerous-jobs/

# Quelques idées dans l'air du temps

- un calendrier de l'avent du gouvernement
- les résultats d’un sondage google form sur les habitudes/intérêts/connaissances de vos camarades
- un calculateur de frais de carburant suite à la hausse des taxes et du baril (en fonction des km parcourus/jour)
- une longue dataviz à scroller pour faire ressentir la longueur parcourue par francis joyon
- ...
